from setuptools import setup

setup(
    author="Mateo",
    author_email="mateomonsegur@gmail.com",
    description="creacion de paquete",
    version="0.0.1",
    name="segunda entrega",
    packages=['Segunda pre-entrega+Monsegur']
)