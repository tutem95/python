from setuptools import setup

setup(
    author="Mateo",
    author_email="mateomonsegur@gmail.com",
    description="creacion de paquete",
    version="0.0.1",
    name="Segunda pre-entrega+Monsegur",
    packages=['Segunda pre-entrega+Monsegur']
)